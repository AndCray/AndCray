This project is my online profile up to the date of 12/11/2024 with many of my accomplishments so far listed. 

Link to my WireFrame for this website: 
https://www.figma.com/design/0AgUd2SO1Yl2XnlEGVFGkF/HTML-Final?node-id=0-1&t=ro4a3hnCxMYcqjvC-1

Link to my Github for this website:
https://github.com/AndCray/AndCray.git

I am using bootstrap as a basis but building my website and design only based off of it. I will not be leaving bootstrap in the program.